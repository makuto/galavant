Jam/MR (aka "jam - make(1) redux")
----------------------------------

For information about Jam/MR, please see:

[http://www.perforce.com/resources/documentation/jam][jam]

The source code is maintained in the [Perforce Workshop][workshop].

The files on this ftp site under /jam/src are a mirror of the
files in the [//guest/perforce_software/jam/src][jamsrc] path in the Workshop.

Copyright 1993-2015 Christopher Seiwald and Perforce Software, Inc.

[jam]: http://www.perforce.com/resources/documentation/jam
[workshop]: https://swarm.workshop.perforce.com/projects/perforce_software-jam
[jamsrc]: https://swarm.workshop.perforce.com/files/guest/perforce_software/jam/src
